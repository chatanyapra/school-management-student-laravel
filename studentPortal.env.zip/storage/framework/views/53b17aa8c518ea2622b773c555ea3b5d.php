<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <?php
        $result = 0;
    ?>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="contentBoxTop">
        <div class="contentTop1">
            <span><span>Student Name: </span><span style="color: rgb(65, 78, 223); word-break: break-all;"><?php echo e($detail->Name); ?></span></span>
            <span><span>Father's Name: </span><span style="color: rgb(65, 78, 223);  word-break: break-all;"><?php echo e($detail->fatherName); ?></span></span>
        </div>
        <div class="contentTop1">
            <span><span>Class: </span><span style="color: rgb(65, 78, 223); text-transform: capitalize;"><?php echo e($class_name); ?></span></span>
            <span><span>Class Rollno: </span><span style="color: rgb(65, 78, 223);"><?php echo e($detail->Sno); ?></span></span>
        </div>
        <div class="contentTop1">
            <span><span>Email: </span><span style="color: rgb(65, 78, 223); word-break: break-all;"><?php echo e($detail->Email); ?></span></span>
            <span><span>Phone No: </span><span
                    style="color: rgb(65, 78, 223); word-break: break-all;"><?php echo e($detail->phoneNo); ?></span></span>
        </div>
    </div>
    <div class="contentBoxTop">
        <div class="studentDetailBox">
            <span>
                <h2><?php echo e(number_format($net_att, 0)); ?>%</h2>
                <div class="progress" style="height: 7px; background-color: rgb(230, 224, 224); border-radius: 20px;">
                    <div class="progress-bar" style="width:<?php echo e(number_format($net_att, 0)); ?>%; height: 7px;"></div>
                </div>
            </span>
            <h4>Attendence</h4>
        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="studentDetailBox">
            <span>
                <h2><?php echo e($result_user ? $result_user : 0); ?>%</h2>
                <div class="progress" style="height: 7px; background-color: rgb(230, 224, 224); border-radius: 20px;">
                    <div class="progress-bar" style="width:<?php echo e($result_user ? $result_user : 0); ?>%; height: 7px;"></div>
                </div>
            </span>
            <span><h4>Result Percent</h4><small  class="result_percent">Half-yearly</small></span>
        </div>
        <div class="studentDetailBox">
            <span>
                <h2>40%</h2>
                <div class="progress" style="height: 7px; background-color: rgb(230, 224, 224); border-radius: 20px;">
                    <div class="progress-bar" style="width:40%; height: 7px;"></div>
                </div>
            </span>
            <h4>Test Result</h4>
        </div>
    </div>

    <div class="tableOfAddtendenceBlock">
        <div class="containerMainAttandance" style="width: 95%; min-height: 250px; justify-content:space-between;">
                <h4 class="pt-2">Attendence</h4>
            <table class="mt-2">
                <?php
                    $arr= array();
                    $num= 0;
                ?>
                <?php if(!empty($total_att_sub)): ?> 
                    <?php $__currentLoopData = $total_att_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $net_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $attendance_subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att_took): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <?php if($net_sub->sub_name == $att_took->sub_name): ?>
                            <?php array_push($arr, $att_took->sub_name) ?>
                            <tr>
                                <td class="subjectOfBar"><?php echo e($att_took->sub_name); ?></td>
                                <td class="progressBarClass">
                                    <div class="progress">
                                        <div class="progress-bar" title="Physics" data-bs-toggle="popover" data-bs-trigger="hover"
                                        data-bs-placement="top" data-bs-content="chatanya" style="width:<?php echo e($att_took->percent); ?>%"><?php echo e($att_took->percent); ?>%</div>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                    <?php $__currentLoopData = $total_att_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $net_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!in_array($net_sub->sub_name, $arr)): ?>
                            <tr>
                                <td class="subjectOfBar"><?php echo e($net_sub->sub_name); ?></td>
                                <td class="progressBarClass">
                                    <div class="progress">
                                        <div class="progress-bar" title="Physics" data-bs-toggle="popover" data-bs-trigger="hover"
                                        data-bs-placement="top" data-bs-content="chatanya" style="width:0%">0%</div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="subjectOfBarLast"></td>
                    <td class="progressBarLast"></td>
                </tr>
                <tr>
                    <td class="subjectOfBarLast"></td>
                    <td class="progressBarLast2">0
                        <span>
                            <p>20</p>
                        </span>
                        <span>
                            <p>40</p>
                        </span>
                        <span>
                            <p>60</p>
                        </span>
                        <span>
                            <p>80</p>
                        </span>
                        <span>
                            <p>100</p>
                        </span>
                    </td>
                </tr>
            </table>
        </div>
        <div class="containerMainAttandance" style="width: 95%;">
            <div class="messageInformationBox" style="width: 90%;">
                <header>
                    <h4>Messages</h4><span></span>
                </header>
                <div>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher_message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!empty($teacher_message->messageBox)): ?>    
                        <div class="messageBox">
                            <span class="messageBoxImage"><img src="<?php echo e(URL::asset("$teacher_message->photo")); ?>" width="88px"
                                height="80px" alt="image"></span>
                                <span class="messageBoxContent"><span style="float: left;">&#128172; </span>
                                <?php echo e($teacher_message->messageBox); ?>

                            </span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- ----------created a div block of teacher of studemts------------------ -->
    <Header
        style="text-align: center; color: blue; font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">
        <h4>Academic Details</h4>
    </Header>
<?php $__currentLoopData = $attendance_subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att_took): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    <div class="allTeacherInfoContain1">
        <span class="allInfoInternalBox1">
            <span style="display: flex;"><img src="<?php echo e($att_took->photo); ?>" width="60px" height="50px"
                    style="border-radius: 50%; margin-right: 20px;" alt="Teacher">
                <span><b><?php echo e($att_took->Name); ?></b><br> <?php echo e($att_took->sub_name); ?></span>
            </span>
        </span>
        <span class="allInfoInternalBox2">
            <span style="min-width: 240px;">
                <h5><?php echo e(number_format($att_took->percent, 0)); ?> %</h5>
                <div class="progress" style="height: 7px; background-color: rgb(230, 224, 224); border-radius: 20px;">
                    <div class="progress-bar" style="width:<?php echo e(number_format($att_took->percent, 0)); ?>%; height: 7px; background-color:red"></div>
                </div>
            </span>
            <span class="smallBoxAttend">
                <span style="padding-left:14px;">
                    <p>Held: <span style="background-color: black;"><?php echo e($att_took->sub); ?></span></p>
                </span>
                <span style="padding-left:14px;">
                    <p>Attend: <span style="background-color: #00cc00;"><?php echo e($att_took->pre); ?></span></p>
                </span>
                <span style="padding-left:14px;">
                    <p>Leave: <span style="background-color: #ff0000;"><?php echo e(($att_took->sub - $att_took->pre)); ?></span></p>
                </span>
            </span>
            <button type="button" style="display: block; min-width: 50px;" onclick="buttonAboutYouFunc(this)">More</button>
        </span>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $total_att_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $net_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(!in_array($net_sub->sub_name, $arr)): ?>
        <div class="allTeacherInfoContain1">
            <span class="allInfoInternalBox1">
                <span style="display: flex;"><img src="<?php echo e($net_sub->photo); ?>" width="60px" height="50px"
                        style="border-radius: 50%; margin-right: 20px;" alt="Teacher">
                    <span><b><?php echo e($net_sub->Name); ?></b><br> <?php echo e($net_sub->sub_name); ?></span>
                </span>
            </span>
            <span class="allInfoInternalBox2">
                <span style="min-width: 240px;">
                    <h5>0%</h5>
                    <div class="progress" style="height: 7px; background-color: rgb(230, 224, 224); border-radius: 20px;">
                        <div class="progress-bar" style="width:0%; height: 7px; background-color:red"></div>
                    </div>
                </span>
                <span class="smallBoxAttend">
                    <span style="padding-left:14px;">
                        <p>Held: <span style="background-color: black;">0</span></p>
                    </span>
                    <span style="padding-left:14px;">
                        <p>Attend: <span style="background-color: #00cc00;">0</span></p>
                    </span>
                    <span style="padding-left:14px;">
                        <p>Leave: <span style="background-color: #ff0000;">0</span></p>
                    </span>
                </span>
                <button type="submit" onclick="buttonAboutYouFunc(this)"
                    style="display: block; min-width: 50px;">More</button>
            </span>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <script>
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    })

    var numSym = 1;

    function buttonAboutYouFunc(event) {
        event.classList.toggle('toggleColorOfSeeButton');
        if (event.innerHTML == 'See Less') {
            event.innerHTML = 'More';
        } else {
            event.innerHTML = 'See Less';
        }
    }
    </script>

<?php
    //         }
    //         else{
    //             echo "<script>window.location.replace('newSch.php')</script>";
    //         }
    //     }
    // }
    // else{
    //     echo "<script>window.location.replace('newSch.php')</script>";
    // }
?>
</body>

</html><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/big-component-files/user-front-page.blade.php ENDPATH**/ ?>