<div class="timeTableMain">
    <table class="timeTableCont1">
        <th colspan="9">Time Table</th>
        <tr>
            <th>Days</th>
            <th>I</th>
            <th>II</th>
            <th>III</th>
            <th>IV</th>
            <th>V</th>
            <th>VI</th>
            <th>VII</th>
            <th>VIII</th>
        </tr>
        <tr class="<?php echo e($week_day == 'Monday' ? 'time_table_class_anim' : 'none'); ?>">
            <th>Monday</th>
            <?php $__currentLoopData = $time_table_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                <?php if($table_item->Monday == 'None'): ?>
                    <td style="box-shadow: 0px 0px 10px 2px rgb(255, 68, 68) inset"><?php echo e($table_item->Monday); ?></td>
                <?php else: ?>
                    <td><?php echo e($table_item->Monday); ?></td>
                <?php endif; ?>          
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="<?php echo e($week_day == 'Tuesday' ? 'time_table_class_anim' : 'none'); ?>">
            <th>Tuesday</th>
            <?php $__currentLoopData = $time_table_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                <?php if($table_item->Tuesday == 'None'): ?>
                    <td style="box-shadow: 0px 0px 10px 2px rgb(255, 68, 68) inset"><?php echo e($table_item->Tuesday); ?></td>
                <?php else: ?>
                    <td><?php echo e($table_item->Tuesday); ?></td>
                <?php endif; ?>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="<?php echo e($week_day == 'Wednesday' ? 'time_table_class_anim' : 'none'); ?>">
            <th>Wednesday</th>
            <?php $__currentLoopData = $time_table_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                 <?php if($table_item->Wednesday == 'None'): ?>
                    <td style="box-shadow: 0px 0px 10px 2px rgb(255, 68, 68) inset"><?php echo e($table_item->Wednesday); ?></td>
                <?php else: ?>
                    <td><?php echo e($table_item->Wednesday); ?></td>
                <?php endif; ?>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="<?php echo e($week_day == 'Thursday' ? 'time_table_class_anim' : 'none'); ?>">
            <th>Thursday</th>
            <?php $__currentLoopData = $time_table_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                <?php if($table_item->Thursday == 'None'): ?>
                    <td style="box-shadow: 0px 0px 10px 2px rgb(255, 68, 68) inset"><?php echo e($table_item->Thursday); ?></td>
                <?php else: ?>
                    <td><?php echo e($table_item->Thursday); ?></td>
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="<?php echo e($week_day == 'Friday' ? 'time_table_class_anim' : 'none'); ?>">
            <th>Friday</th>
            <?php $__currentLoopData = $time_table_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                <?php if($table_item->Friday == 'None'): ?>
                    <td style="box-shadow: 0px 0px 10px 2px rgb(255, 68, 68) inset"><?php echo e($table_item->Friday); ?></td>
                <?php else: ?>
                    <td><?php echo e($table_item->Friday); ?></td>
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <tr class="<?php echo e($week_day == 'Saturday' ? 'time_table_class_anim' : 'none'); ?>">
            <th>Saturday</th>
            <?php $__currentLoopData = $time_table_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                <?php if($table_item->Saturday == 'None'): ?>
                    <td style="box-shadow: 0px 0px 10px 2px rgb(255, 68, 68) inset"><?php echo e($table_item->Saturday); ?></td>
                <?php else: ?>
                    <td><?php echo e($table_item->Saturday); ?></td>
                <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
</div><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/big-component-files/time-table-page.blade.php ENDPATH**/ ?>