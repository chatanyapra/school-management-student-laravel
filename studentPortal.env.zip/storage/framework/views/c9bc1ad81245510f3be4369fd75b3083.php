
<?php $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="MyadvisorMain">
        <header>
            <span style="padding-left: 20px;" class="material-symbols-sharp hideBox">person</span>
            <h5> My Class Advisor Details </h5>
        </header>
        <div class="myadvisorBox1">
            <img src='<?php echo e(URL::asset("$faculty->photo")); ?>' width="170" height="150" alt="Advisor Image">
            <div class="divmyadvisorBox1">
                <span style="display: flex; font-size: 16px;"><span style="font-size: 24px;" class="material-symbols-sharp">person</span><?php echo e($faculty->Name); ?></span>
                <span style="display: flex; font-size: 16px;"><span style="font-size: 22px;" class="material-symbols-sharp">Mail</span><?php echo e($faculty->Email); ?></span>
                <span style="display: flex; font-size: 16px;"><span style="font-size: 22px;" class="material-symbols-sharp">phone_in_talk</span><?php echo e($faculty->phoneNo); ?></span>
            </div>
        </div>
    </div>
    <?php break; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/small-files/advisor-profile.blade.php ENDPATH**/ ?>