<?php $__currentLoopData = $student_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_fees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="MyadvisorMain">
        <header>
            <span style="padding-left: 20px;" class="material-symbols-sharp hideBox">currency_rupee</span>
            <h5> My Fees Details </h5>
        </header>
        <div class="myFeesBox">
            <div>Academic</div>
            <span><strong>Net Fees </strong><span><strong><?php echo e($user_fees->total_fees + 2000); ?></strong></span></span>
            <span>Practical Fees<span> 2000</span></span>
            <span>Monthly Fees<span><?php echo e($user_fees->total_fees / 12); ?></span></span>
            <span>Bus Fees<span>None</span></span>
            <span>Fine <span>00</span></span>
            <span>Paid<span><?php echo e($user_fees->feesSubmitted); ?></span></span>
            <span class="balanceClassSpan">Balance <span><?php echo e($user_fees->total_fees - $user_fees->feesSubmitted); ?></span></span>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/small-files/acad-fees-detail.blade.php ENDPATH**/ ?>