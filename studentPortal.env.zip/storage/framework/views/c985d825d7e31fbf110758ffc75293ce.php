<?php $__currentLoopData = $student_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mainInternalDivOfReg">
        <div class="internalBoxStatus">
            <blockquote>Activity <span style="color: blue;">Registration</span></blockquote>
            <blockquote>Status <span style="color: rgb(12, 210, 26);">You Are <?php echo e($item->ClassRegistration); ?></span></blockquote>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/small-files/academic-reg.blade.php ENDPATH**/ ?>