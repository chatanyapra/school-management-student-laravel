    <table class="attendenceTableBox">
        <tr style="text-align: center;">
            <td style="border: none;" >S.no</td>
            <td style="width: 40%; border: none;">Date</td>
            <td style="border: none;" >Attendence</td>
        </tr>
<?php $i=1; ?>
<?php $__currentLoopData = $attendance_of_subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr style="text-align: center; border-bottom: 0.5px solid black;">
        <td style="border: none;" ><?php echo e($i); ?></td>
        <td style="width: 40%; border: none;"><?php echo e($data->attendence_date); ?></td>
        <td style="border: none;">
            <span style="padding: 2px 15px; border-radius: 15px; color: white; background-color: <?php echo e($data->attendence_status == 'P' ? 'green' : 'red'); ?>;"> <?php echo e($data->attendence_status); ?> </span>
        </td>
    </tr>
    <?php $i++; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/small-files/attendance-show-table.blade.php ENDPATH**/ ?>