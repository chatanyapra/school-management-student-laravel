
<div class="mainInternalDivOfReg">
    <div class="internalBoxStatus">
        <header style="border-bottom: 1px solid black; display: flex; margin-bottom: 10px;"><span class="material-symbols-sharp" style="font-size: 50px; color: rgb(246, 239, 38);">
            directions_bus
            </span>
            <h2 style="padding: 5px 10px;">Transport Details</h2>
        </header>
        <blockquote style="display: flex; justify-content: space-evenly;"><span style="color: rgb(0, 47, 255); width: 50%; "> Fees</span><span style="color: rgb(12, 210, 26); width: 50%;">No</span></blockquote>
        <blockquote style="display: flex; justify-content: space-evenly;"><span style="color: rgb(0, 47, 255); width: 50%; "> Deposited</span><span style="color: rgb(12, 210, 26); width: 50%;">No</span></blockquote>
    </div>
</div><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/small-files/transport-fees.blade.php ENDPATH**/ ?>