
<div class="selectSubAttendence">
    <select id="selectSubject" class="form-select w-50 my-4" aria-label="Default select example" onchange="selectedSubject(this.value)">
        <option selected>Choose Subject</option>
        <?php $__currentLoopData = $attendance_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->sub_name); ?>"> <?php echo e($item->sub_name); ?> </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
    <span id="subjectName" style="margin: auto 0; font-weight: bold; color: #21b200;">English</span>
</div>
<div class="attendenceMainSec" id="show-attendance-Box">

</div><?php /**PATH C:\xampp new\htdocs\school-management-student-laravel\resources\views/big-component-files/attendance-page.blade.php ENDPATH**/ ?>